package ARRAYS.strivers;

public class Q22 {


    public static void main(String[] args) {

        //



    }
}
